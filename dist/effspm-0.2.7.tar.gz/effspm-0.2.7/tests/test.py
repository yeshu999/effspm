import os, psutil, threading

def log_mem():
    p = psutil.Process(os.getpid())
    while True:
        print(f"[mem] {p.memory_info().rss/1024**2:.1f} MB")
        time.sleep(1)

# start background logger
t = threading.Thread(target=log_mem, daemon=True)
t.start()

# now run your mine
from effspm import LargeBTMiner
result = LargeBTMiner(
    data="/Users/yeswanthvootla/Desktop/final_kosarak_s.txt",
    minsup=0.01,
    time_limit=36000,
    preproc=False,
    use_dic=False,
    verbose=False,
    out_file="/Users/yeswanthvootla/Desktop/final_kosarak_s_LBM2.txt"
)

# extract the patterns and timing from the returned dict
patterns = result["patterns"]
wall_time = result["time"]

print(f"Found {len(patterns)} patterns")
print("Patterns:", patterns)